import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseServer";
import { getOpenAI } from "@/lib/openai";

export const runtime = "nodejs";

type Plan = "free" | "pro" | "premium";
type WindowType = "month" | "year";

function entitlement(plan: Plan): { windowType: WindowType; runsLimit: number } {
  if (plan === "pro") return { windowType: "month", runsLimit: 120 };
  if (plan === "premium") return { windowType: "year", runsLimit: 5000 };
  return { windowType: "month", runsLimit: 5 };
}

function firstDayOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

function formatDateOnly(d: Date) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export async function POST(request: Request) {
  try {
    // ===== 1. AUTH =====
    const authHeader = request.headers.get("authorization") || "";
    const token = authHeader.startsWith("Bearer ")
      ? authHeader.slice(7)
      : "";

    if (!token) {
      return NextResponse.json(
        { ok: false, error_code: "NOT_AUTHENTICATED" },
        { status: 401 }
      );
    }

    const { data: userData, error: userErr } =
      await supabaseAdmin.auth.getUser(token);

    const user = userData?.user;

    if (userErr || !user) {
      return NextResponse.json(
        { ok: false, error_code: "NOT_AUTHENTICATED" },
        { status: 401 }
      );
    }

    // ===== 2. INPUT =====
    const body = await request.json().catch(() => ({}));
    const text = typeof body?.text === "string" ? body.text : "";
    const charCount = text.length;

    if (!text) {
      return NextResponse.json(
        { ok: false, error_code: "EMPTY_TEXT" },
        { status: 400 }
      );
    }

    if (charCount > 5000) {
      return NextResponse.json(
        { ok: false, error_code: "TEXT_TOO_LONG" },
        { status: 400 }
      );
    }

    // ===== 3. SUBSCRIPTION =====
    const { data: subExisting } = await supabaseAdmin
      .from("subscriptions")
      .select("plan, current_period_start")
      .eq("user_id", user.id)
      .maybeSingle();

    if (!subExisting) {
      await supabaseAdmin.from("subscriptions").insert({
        user_id: user.id,
        plan: "free",
        status: "active",
      });
    }

    const { data: sub } = await supabaseAdmin
      .from("subscriptions")
      .select("plan, current_period_start")
      .eq("user_id", user.id)
      .maybeSingle();

    const plan: Plan = (sub?.plan as Plan) ?? "free";
    const { windowType, runsLimit } = entitlement(plan);

    // ===== 4. WINDOW =====
    const now = new Date();
    const windowStart =
      windowType === "month"
        ? formatDateOnly(firstDayOfMonth(now))
        : sub?.current_period_start
        ? formatDateOnly(new Date(sub.current_period_start))
        : `${now.getFullYear()}-01-01`;

    const { data: win } = await supabaseAdmin
      .from("usage_windows")
      .select("runs_used, runs_limit")
      .eq("user_id", user.id)
      .eq("window_type", windowType)
      .eq("window_start", windowStart)
      .maybeSingle();

    const runsUsed = win?.runs_used ?? 0;
    const limit = win?.runs_limit ?? runsLimit;

    if (!win) {
      await supabaseAdmin.from("usage_windows").insert({
        user_id: user.id,
        window_type: windowType,
        window_start: windowStart,
        plan,
        runs_used: 0,
        runs_limit: limit,
      });
    }

    if (runsUsed >= limit) {
      return NextResponse.json(
        {
          ok: false,
          error_code: "QUOTA_EXCEEDED",
          plan,
          runsLeft: 0,
          upgrade_url: "/pricing",
        },
        { status: 402 }
      );
    }

    // ===== 5. CONSUME QUOTA =====
    const { data: updated } = await supabaseAdmin
      .from("usage_windows")
      .update({ runs_used: runsUsed + 1 })
      .eq("user_id", user.id)
      .eq("window_type", windowType)
      .eq("window_start", windowStart)
      .select("runs_used")
      .maybeSingle();

    const newUsed = updated?.runs_used ?? runsUsed + 1;
    const runsLeft = Math.max(0, limit - newUsed);

    // ===== 6. OPENAI CALL =====
    const openai = getOpenAI();

    let tokensIn = 0;
    let tokensOut = 0;

    const system = `You are BEAM, Behavioral Message Auditor.
Analyze and improve written messages using Behavioural Economics.
Return valid JSON only.`;

    const userPrompt = `MESSAGE:
"""
${text}
"""

Return JSON with:
goal,
audience_assumption,
frictions[],
behavioral_levers[],
rewrite,
checklist[],
short_explanation.`;

    const resp: any = await Promise.race([
      openai.responses.create({
        model: "gpt-5-mini",
        input: [
          { role: "system", content: system },
          { role: "user", content: userPrompt },
        ],
        text: { format: { type: "json_object" } },
      }),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error("OpenAI timeout")), 20000)
      ),
    ]);

    const usageAny: any = resp?.usage ?? null;
    tokensIn = usageAny?.input_tokens ?? 0;
    tokensOut = usageAny?.output_tokens ?? 0;

    const raw = resp?.output_text ?? "";
    let beamJson: any = null;

    try {
      beamJson = JSON.parse(raw);
    } catch {
      beamJson = {
        goal: "",
        audience_assumption: "",
        frictions: [],
        behavioral_levers: [],
        rewrite: "",
        checklist: [],
        short_explanation: raw,
      };
    }

    // ===== 7. LOG USAGE =====
    await supabaseAdmin.from("usage_logs").insert({
      user_id: user.id,
      tool: "beam",
      char_count: charCount,
      tokens_in: tokensIn,
      tokens_out: tokensOut,
      cost_estimate_eur: 0,
      success: true,
    });

    // ===== 8. RESPONSE =====
    return NextResponse.json({
      ok: true,
      tool: "beam",
      plan,
      runsLeft,
      result: beamJson,
    });

  } catch (e: any) {
    console.error("RUN_BEAM ERROR:", e);
    return NextResponse.json(
      {
        ok: false,
        error_code: "SERVER_ERROR",
        message: e?.message ?? "Server error",
      },
      { status: 500 }
    );
  }
}