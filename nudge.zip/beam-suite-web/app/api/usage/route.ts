import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseServer";

type Plan = "free" | "pro" | "premium";
type WindowType = "month" | "year";

function firstDayOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

function formatDateOnly(d: Date) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function entitlement(plan: Plan): { windowType: WindowType; runsLimit: number } {
  if (plan === "pro") return { windowType: "month", runsLimit: 120 };
  if (plan === "premium") return { windowType: "year", runsLimit: 5000 };
  return { windowType: "month", runsLimit: 5 };
}

export async function GET(request: Request) {
  const authHeader = request.headers.get("authorization") || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";

  if (!token) {
    return NextResponse.json({ ok: false, error: "Not authenticated" }, { status: 401 });
  }

  const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
  const user = userData?.user;

  if (userErr || !user) {
    return NextResponse.json({ ok: false, error: "Not authenticated" }, { status: 401 });
  }

  const { data: sub } = await supabaseAdmin
    .from("subscriptions")
    .select("plan, current_period_start")
    .eq("user_id", user.id)
    .maybeSingle();

  const plan = (sub?.plan as Plan) ?? "free";
  const { windowType, runsLimit } = entitlement(plan);

  const now = new Date();
  let windowStart = "";

  if (windowType === "month") {
    windowStart = formatDateOnly(firstDayOfMonth(now));
  } else {
    windowStart = sub?.current_period_start
      ? formatDateOnly(new Date(sub.current_period_start))
      : `${now.getFullYear()}-01-01`;
  }

  const { data: win } = await supabaseAdmin
    .from("usage_windows")
    .select("runs_used, runs_limit")
    .eq("user_id", user.id)
    .eq("window_type", windowType)
    .eq("window_start", windowStart)
    .maybeSingle();

  const runsUsed = win?.runs_used ?? 0;
  const limit = win?.runs_limit ?? runsLimit;
  const runsLeft = Math.max(0, limit - runsUsed);

  return NextResponse.json({
    ok: true,
    plan,
    windowType,
    windowStart,
    runsUsed,
    runsLimit: limit,
    runsLeft,
  });
}