"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

export default function BeamPage() {
  const [text, setText] = useState("");
  const [runsLeft, setRunsLeft] = useState<number | null>(null);
  const [plan, setPlan] = useState<string | null>(null);
  const [status, setStatus] = useState<"idle" | "running" | "error" | "blocked">("idle");
  const [message, setMessage] = useState<string>("");

  const charCount = useMemo(() => text.length, [text]);

  const fetchUsage = async () => {
    const { data } = await supabase.auth.getSession();
    const token = data.session?.access_token;
    if (!token) return;

    const r = await fetch("/api/usage", {
      headers: { Authorization: `Bearer ${token}` },
    });

    let j: any = null;
const contentType = r.headers.get("content-type") || "";

try {
  if (contentType.includes("application/json")) {
    j = await r.json();
  } else {
    const txt = await r.text();
    j = { ok: false, message: txt };
  }
} catch (e: any) {
  j = { ok: false, message: e?.message ?? "Failed to parse server response" };
}

if (!r.ok) {
  setStatus("error");
  setMessage(j?.message ?? `Server error (${r.status})`);
  return;
}
    if (j.ok) {
      setRunsLeft(j.runsLeft);
      setPlan(j.plan);
    }
  };

  useEffect(() => {
    fetchUsage();
  }, []);

  const runBeam = async () => {
    if (runsLeft !== null && runsLeft <= 0) {
      setStatus("blocked");
      setMessage("You have reached your limit. Please upgrade to continue.");
      return;
    }
    setStatus("running");
    setMessage("");

    const { data } = await supabase.auth.getSession();
    const token = data.session?.access_token;

    if (!token) {
      setStatus("error");
      setMessage("Not authenticated. Please log in again.");
      return;
    }

    if (charCount > 5000) {
      setStatus("error");
      setMessage("Text too long. Max is 5,000 characters.");
      return;
    }

    const r = await fetch("/api/run/beam", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ text }),
    });

    const j = await r.json();

    if (!j.ok && j.error_code === "QUOTA_EXCEEDED") {
      setStatus("blocked");
      setRunsLeft(0);
      setPlan(j.plan ?? plan);
      setMessage("You have reached your limit. Please upgrade to continue.");
      return;
    }

    if (!j.ok) {
      setStatus("error");
      setMessage(j.message ?? "Something went wrong.");
      return;
    }

    setStatus("idle");
    setRunsLeft(j.runsLeft);
    setPlan(j.plan ?? plan);
    setMessage("Run completed successfully.");
  };

  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: 40, fontFamily: "Arial" }}>
      <h1 style={{ marginTop: 0 }}>BEAM</h1>
      <p style={{ color: "#666" }}>Behavioral Message Auditor</p>

      <div style={{ display: "flex", gap: 12, alignItems: "center", marginTop: 10 }}>
        <span style={{ padding: "6px 10px", border: "1px solid #eee", borderRadius: 999 }}>
          Plan: {plan ?? "…"}
        </span>
        <span style={{ padding: "6px 10px", border: "1px solid #eee", borderRadius: 999 }}>
          Runs left: {runsLeft ?? "…"}
        </span>
        <a href="/pricing" style={{ marginLeft: "auto" }}>
          Upgrade
        </a>
      </div>

      <label style={{ display: "block", marginTop: 18, marginBottom: 8, fontWeight: 600 }}>
        Paste your message (max 5,000 characters)
      </label>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={10}
        placeholder="Write or paste your message here…"
        style={{ width: "100%", padding: 12, borderRadius: 12, border: "1px solid #ddd" }}
      />

      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10, color: "#666" }}>
        <span>{charCount}/5000</span>
        <button
          onClick={runBeam}
          disabled={status === "running" || status === "blocked"}
          style={{
            padding: "10px 14px",
            borderRadius: 12,
            border: "1px solid #111",
            background: "white",
            cursor: "pointer",
            fontWeight: 700,
          }}
        >
          {status === "running" ? "Running..." : "Run BEAM"}
        </button>
      </div>

      {message && (
        <p
          style={{
            marginTop: 14,
            color:
              status === "error"
                ? "crimson"
                : status === "blocked"
                ? "#a15c00"
                : "black",
          }}
        >
          {message}
        </p>
      )}

      <p style={{ marginTop: 24 }}>
        <a href="/app">Back to dashboard</a>
      </p>
    </main>
  );
}