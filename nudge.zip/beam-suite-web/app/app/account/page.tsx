export default function AccountPage() {
    return (
      <main style={{ maxWidth: 1000, margin: "0 auto", padding: 40, fontFamily: "Arial" }}>
        <h1>Account</h1>
        <p>Billing and usage will appear here later.</p>
        <p><a href="/app">Back to dashboard</a></p>
      </main>
    );
  }
  