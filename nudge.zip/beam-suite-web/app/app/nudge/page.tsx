export default function NudgePage() {
    return (
      <main style={{ maxWidth: 1000, margin: "0 auto", padding: 40, fontFamily: "Arial" }}>
        <h1>Nudge Designer</h1>
        <p>This page will run Nudge Designer via API in the next step.</p>
        <p><a href="/app">Back to dashboard</a></p>
      </main>
    );
  }
  