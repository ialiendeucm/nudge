export default function Home() {
  const tools = [
    {
      name: "BEAM, Behavioral Message Auditor",
      description:
        "Analyze written messages through the lens of Behavioral Economics and improve clarity, influence, and structure.",
      href: "#",
      note: "Replace with your ChatGPT GPT link",
    },
    {
      name: "Nudge Designer",
      description:
        "Generate practical, ethical nudges for organizations, public policy, communication, and behavior change.",
      href: "#",
      note: "Replace with your ChatGPT GPT link",
    },
    {
      name: "Causal Lab",
      description:
        "Support causal reasoning, evaluation design, and research-oriented decision frameworks in applied settings.",
      href: "#",
      note: "Replace with your ChatGPT GPT link",
    },
  ];

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <header className="border-b border-slate-200">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">
              Behavioral Economics Tools
            </p>
            <h1 className="mt-1 text-2xl font-semibold">Iñaki Aliende</h1>
          </div>
          <nav className="hidden gap-6 text-sm text-slate-600 md:flex">
            <a href="#tools" className="hover:text-slate-900">Tools</a>
            <a href="#about" className="hover:text-slate-900">About</a>
            <a href="#contact" className="hover:text-slate-900">Contact</a>
          </nav>
        </div>
      </header>

      <main>
        <section className="mx-auto grid max-w-6xl gap-10 px-6 py-16 md:grid-cols-[1.25fr_0.75fr] md:py-24">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">
              Research-backed GPT tools
            </p>
            <h2 className="mt-4 max-w-3xl text-4xl font-semibold leading-tight md:text-5xl">
              A bridge site to access my GPTs on Behavioral Economics, nudging, and causal thinking.
            </h2>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
              This site brings together a small suite of GPT-based tools developed to support applied work in communication, behavior change, and analytical reasoning. The tools are designed with an academic and practical orientation, combining clarity, usability, and evidence-informed thinking.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <a
                href="#tools"
                className="rounded-2xl bg-slate-900 px-5 py-3 text-sm font-medium text-white shadow-sm transition hover:opacity-90"
              >
                Explore the tools
              </a>
              <a
                href="#about"
                className="rounded-2xl border border-slate-300 px-5 py-3 text-sm font-medium text-slate-800 transition hover:border-slate-400"
              >
                Academic profile
              </a>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6 shadow-sm">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">
              Current suite
            </p>
            <div className="mt-5 space-y-4">
              {tools.map((tool) => (
                <div key={tool.name} className="rounded-2xl border border-slate-200 bg-white p-4">
                  <h3 className="text-base font-semibold">{tool.name}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-600">{tool.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="tools" className="border-t border-slate-200 bg-slate-50/70">
          <div className="mx-auto max-w-6xl px-6 py-16 md:py-20">
            <div className="max-w-2xl">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">
                Tools
              </p>
              <h2 className="mt-3 text-3xl font-semibold md:text-4xl">
                Three GPTs for applied Behavioral Economics
              </h2>
              <p className="mt-4 text-base leading-7 text-slate-600">
                Each tool is designed as a practical entry point to a specific task. The site acts as a bridge, making access simpler and presenting each GPT within a coherent academic and professional framework.
              </p>
            </div>

            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {tools.map((tool) => (
                <article key={tool.name} className="flex flex-col rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
                  <h3 className="text-xl font-semibold leading-7">{tool.name}</h3>
                  <p className="mt-4 flex-1 text-sm leading-7 text-slate-600">{tool.description}</p>
                  <div className="mt-6">
                    <a
                      href={tool.href}
                      className="inline-flex rounded-2xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition hover:opacity-90"
                    >
                      Open GPT
                    </a>
                    <p className="mt-3 text-xs text-slate-500">{tool.note}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="about" className="mx-auto max-w-6xl px-6 py-16 md:py-20">
          <div className="grid gap-10 md:grid-cols-[0.9fr_1.1fr]">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">
                About
              </p>
              <h2 className="mt-3 text-3xl font-semibold md:text-4xl">Academic profile and applied orientation</h2>
            </div>
            <div className="space-y-5 text-base leading-8 text-slate-600">
              <p>
                These tools are presented within an academic-professional profile focused on Applied Economics, Behavioral Economics, Data Science, and evaluation. Their purpose is not only to provide AI support, but also to translate structured reasoning into practical use.
              </p>
              <p>
                The bridge site can be used as a public-facing profile, a research-backed landing page, or an entry point for collaborations, training, and applied projects.
              </p>
              <p>
                You can later extend this site with publications, case studies, event talks, or examples of how the GPTs are used in education, consulting, and organizational settings.
              </p>
            </div>
          </div>
        </section>

        <section id="contact" className="border-t border-slate-200 bg-slate-900 text-white">
          <div className="mx-auto max-w-6xl px-6 py-16 md:py-20">
            <div className="grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-400">
                  Contact
                </p>
                <h2 className="mt-3 text-3xl font-semibold md:text-4xl">
                  For academic collaboration, training, or applied projects
                </h2>
                <p className="mt-4 max-w-2xl text-base leading-7 text-slate-300">
                  This site can work as a simple bridge to your GPTs, but also as a professional page to present your work and invite collaborations.
                </p>
              </div>
              <a
                href="mailto:ialiende@ucm.es"
                className="inline-flex rounded-2xl bg-white px-5 py-3 text-sm font-medium text-slate-900 transition hover:bg-slate-100"
              >
                Contact by email
              </a>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}