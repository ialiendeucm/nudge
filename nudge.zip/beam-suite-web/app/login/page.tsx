"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type Mode = "signin" | "signup";

export default function LoginPage() {
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState<"idle" | "working" | "ok" | "error">("idle");
  const [message, setMessage] = useState("");

  const run = async () => {
    setStatus("working");
    setMessage("");

    if (!email || !password) {
      setStatus("error");
      setMessage("Please enter email and password.");
      return;
    }

    if (mode === "signup") {
      const { error } = await supabase.auth.signUp({ email, password });
      if (error) {
        setStatus("error");
        setMessage(error.message);
        return;
      }
      setStatus("ok");
      setMessage("Account created. You can now sign in.");
      setMode("signin");
      return;
    }

    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setStatus("error");
      setMessage(error.message);
      return;
    }

    window.location.href = "/app";
  };

  return (
    <main style={{ maxWidth: 520, margin: "0 auto", padding: 40, fontFamily: "Arial" }}>
      <h1>{mode === "signin" ? "Log in" : "Create account"}</h1>

      <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
        <button
          onClick={() => setMode("signin")}
          style={{
            padding: "10px 14px",
            borderRadius: 12,
            border: mode === "signin" ? "1px solid #111" : "1px solid #ddd",
            background: "white",
            cursor: "pointer",
            fontWeight: mode === "signin" ? 700 : 400,
          }}
        >
          Sign in
        </button>
        <button
          onClick={() => setMode("signup")}
          style={{
            padding: "10px 14px",
            borderRadius: 12,
            border: mode === "signup" ? "1px solid #111" : "1px solid #ddd",
            background: "white",
            cursor: "pointer",
            fontWeight: mode === "signup" ? 700 : 400,
          }}
        >
          Sign up
        </button>
      </div>

      <label style={{ display: "block", marginTop: 18, marginBottom: 6 }}>Email</label>
      <input
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@domain.com"
        style={{ width: "100%", padding: 12, borderRadius: 10, border: "1px solid #ddd" }}
      />

      <label style={{ display: "block", marginTop: 14, marginBottom: 6 }}>Password</label>
      <input
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        type="password"
        placeholder="••••••••"
        style={{ width: "100%", padding: 12, borderRadius: 10, border: "1px solid #ddd" }}
      />

      <button
        onClick={run}
        disabled={status === "working"}
        style={{
          marginTop: 16,
          padding: "12px 16px",
          borderRadius: 12,
          border: "1px solid #111",
          background: "white",
          cursor: "pointer",
          fontWeight: 600,
          width: "100%",
        }}
      >
        {status === "working" ? "Working..." : mode === "signin" ? "Log in" : "Create account"}
      </button>

      {message && (
        <p style={{ marginTop: 12, color: status === "error" ? "crimson" : "black" }}>
          {message}
        </p>
      )}

      <p style={{ marginTop: 24 }}>
        <a href="/">Back to home</a>
      </p>
    </main>
  );
}