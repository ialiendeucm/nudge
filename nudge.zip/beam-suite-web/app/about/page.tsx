export default function AboutPage() {
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: 40, fontFamily: "Arial" }}>
      <h1>About</h1>
      <p style={{ fontSize: 18 }}>
        BEAM Suite is a practical set of behavioral tools for communication, nudging, and causal thinking.
      </p>
      <p>Developed by Professor and Researcher Iñaki Aliende, contact: ialiende@ucm.es</p>
      <p style={{ marginTop: 30 }}>
        <a href="/">Back to home</a>
      </p>
    </main>
  );
}
