export default function PricingPage() {
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: 40, fontFamily: "Arial" }}>
      <h1>Pricing</h1>
      <p style={{ fontSize: 18 }}>One plan, everything included.</p>

      <div style={{ marginTop: 20, border: "1px solid #eee", borderRadius: 16, padding: 18, maxWidth: 480 }}>
        <h2 style={{ marginTop: 0 }}>€12/year</h2>
        <p>Includes BEAM, Nudge Designer, and Causal Lab</p>
        <p>60 runs per month</p>
        <p>PDF export</p>

        <a
          href="/login"
          style={{
            display: "inline-block",
            marginTop: 10,
            padding: "12px 18px",
            borderRadius: 12,
            border: "1px solid #111",
            textDecoration: "none",
            fontWeight: 600,
          }}
        >
          Subscribe
        </a>
      </div>

      <p style={{ marginTop: 30 }}>
        <a href="/">Back to home</a>
      </p>
    </main>
  );
}
