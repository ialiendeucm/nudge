"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

export default function AuthCallbackPage() {
  const [msg, setMsg] = useState("Signing you in...");

  useEffect(() => {
    const run = async () => {
      // After /auth/v1/verify, Supabase usually redirects with tokens in the URL hash:
      // http://localhost:3000/auth/callback#access_token=...&refresh_token=...&type=magiclink
      const hash = window.location.hash;

      if (!hash || !hash.includes("access_token")) {
        setMsg("No session tokens found. Please try logging in again.");
        return;
      }

      const params = new URLSearchParams(hash.replace("#", ""));
      const access_token = params.get("access_token");
      const refresh_token = params.get("refresh_token");

      if (!access_token || !refresh_token) {
        setMsg("Missing session tokens. Please try logging in again.");
        return;
      }

      const { error } = await supabase.auth.setSession({ access_token, refresh_token });

      if (error) {
        setMsg(`Login failed: ${error.message}`);
        return;
      }

      window.location.href = "/app";
    };

    run();
  }, []);

  return (
    <main style={{ maxWidth: 600, margin: "0 auto", padding: 40, fontFamily: "Arial" }}>
      <h1>BEAM Suite</h1>
      <p>{msg}</p>
    </main>
  );
}
