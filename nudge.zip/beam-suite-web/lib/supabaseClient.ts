import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
// 👇 Solo para desarrollo (debug)
if (typeof window !== "undefined") {
    // @ts-ignore
    window.supabase = supabase;
  }